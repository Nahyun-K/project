#pragma once
#define UP 72
#define LEFT 75
#define RIGHT 77
#define DOWN 80
#define ENTER 13

#define X 5
#define Y 5

int num;
int sub;
int ggdan;

//Start_Help.c
void title(void); //���ӽ���ȭ�� 
int MENU(void);
void print_help(void);

//Menu.c
int MENU2(void);
int MENU3(void);
void dan(void);

//Card.c
void draw_card(void);
void thecard(int a);
void closecard(int x, int y);
void readycard(int x, int y);
void open(int x, int y);
int printcard(int x, int y, char(*cardnum)[10]);
void erasecard(int n1, int n2);
void backcard(int n1, int n2);

//Move.c
void moving(char(*cardnum)[10], int *n1, int *n2);

//Gugudan_Alphabet.c
void gugudan(char(*index)[10], char(*index_res)[5], int n);//������ �迭�� �ֱ�
void random_card(char(*index)[10], char(*index_res)[5], char(*cardnum)[10]);
_Bool compare(char input1[10], char input2[10], char(*index)[10], char(*index_res)[5]);
void alphabet(char(*index)[10], char(*index_res)[5]);

//Past_Info.c
int MENU4(void);
int MENU5(void);
void print_info(void);
void write_info(void);

//End.c
void erase_info(void);
void MENU_END();
void print_End();