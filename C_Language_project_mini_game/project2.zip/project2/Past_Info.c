#include<stdio.h>
#include<windows.h>
#include "puzzle.h"

int MENU4()
{
	int updown = 1;

	gotoxy(12, 6);
	printf("[ �н� ������ �����Ͻðڽ��ϱ�? ]");
	gotoxy(13, 8);
	printf("��");
	gotoxy(13, 9);
	printf("�ƴϿ�");
	gotoxy(11, 8);
	printf("��");

	while (1)
	{
		switch (_getch())
		{
		case UP:
			updown = 1;
			gotoxy(11, 8);
			printf("��");
			gotoxy(11, 9);
			printf(" ");
			break;
		case DOWN:
			updown = 2;
			gotoxy(11, 8);
			printf(" ");
			gotoxy(11, 9);
			printf("��");
			break;
		case ENTER:
			if (updown == 1)
			{
				system("cls");
				return 1;
			}
			else if (updown == 2)
			{
				system("cls");
				return 2;
			}
		}
	}
}
int MENU5()
{
	int updown = 1;

	gotoxy(12, 6);
	printf("[ ���� �н� ������ ���ðڽ��ϱ�? ]");
	gotoxy(13, 8);
	printf("��");
	gotoxy(13, 9);
	printf("�ƴϿ�");
	gotoxy(11, 8);
	printf("��");

	while (1)
	{
		switch (_getch())
		{
		case UP:
			updown = 1;
			gotoxy(11, 8);
			printf("��");
			gotoxy(11, 9);
			printf(" ");
			break;
		case DOWN:
			updown = 2;
			gotoxy(11, 8);
			printf(" ");
			gotoxy(11, 9);
			printf("��");
			break;
		case ENTER:
			printf("%d", updown);
			if (updown == 1)
			{
				system("cls");
				return 1;
			}
			else if (updown == 2)
			{
				system("cls");
				return 2;

			}
		}
	}
}

void write_info(void)
{
	FILE *fpwrite = fopen("game.txt", "a");
	char str1[20] = { '\0' }; char str2[10] = { '\0' };
	if (sub == 1)
	{
		strcpy(str1, "������:");
		str2[0] = ggdan + 48;
		str2[1] = '\n';
		str2[2] = '\0';
		strcat(str1, str2);
		fprintf(fpwrite, str1);
	}
	else if (sub == 2)
	{
		strcpy(str1, "���ĺ���ҹ���\n");
		fprintf(fpwrite, str1);
	}
	fclose(fpwrite);
}

void print_info(void)
{
	FILE* fpread = fopen("game.txt", "r");
	char buffer[40];
	gotoxy(6, 6);
	printf("<���� �н� ���� >\n");
	while (fscanf(fpread, "%s", buffer) != EOF)
	{
		printf("\t\t");
		puts(buffer);
	}
	fclose(fpread);
}
