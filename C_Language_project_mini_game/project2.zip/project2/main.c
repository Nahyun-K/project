﻿#include<stdio.h>
#include<windows.h>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h> //bool, true, false
#include "puzzle.h"


void gotoxy(int x, int y) { //gotoxy함수 
	COORD pos = { 2 * x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
typedef enum { NOCURSOR, SOLIDCURSOR, NORMALCURSOR } CURSOR_TYPE; //커서숨기는 함수에 사용되는 열거형 

void setcursortype(CURSOR_TYPE c) { //커서숨기는 함수 
	CONSOLE_CURSOR_INFO CurInfo;
	switch (c) {
	case NOCURSOR:
		CurInfo.dwSize = 1;
		CurInfo.bVisible = FALSE;
		break;
	case SOLIDCURSOR:
		CurInfo.dwSize = 100;
		CurInfo.bVisible = TRUE;
		break;
	case NORMALCURSOR:
		CurInfo.dwSize = 20;
		CurInfo.bVisible = TRUE;
		break;
	}
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CurInfo);
}

int main(void)
{
	int n1, n2,count = 0;
	char index[8][10];
	char index_res[8][5]; 
	char cardnum[16][10]; //카드임의배정후 구구단식과 결과를 담을 배열
	_Bool judge = false;
	srand((unsigned)time(NULL)); //난수표생성 
	setcursortype(NOCURSOR); //커서 없앰 
	title(); //메인타이틀 호출 
		   //reset(); //게임판 리셋
	MENU2();
	//printf("%d", num);   //sub은 1또는2 : 1=구구단배열연결 2=영어연결하기
	if (sub == 1)
	{
		dan();
	}
	MENU3();
	
	if (sub == 1)
	{
		gugudan(index, index_res, ggdan);
		random_card(index, index_res, cardnum);
		/*
		printf("random_card 함수 실행 \n");
		for (int i = 0; i < num * 8; i++)
			printf("%d : %s \n", i, cardnum[i]);
		*/
	}
	else if (sub == 2)
	{
		alphabet(index, index_res);
		random_card(index, index_res, cardnum);
		/*
		for (int i = 0; i < num * 8; i++)
			printf("%d : %s \n", i, cardnum[i]);
		*/
	}

	draw_card();
	while (1)
	{
		moving(cardnum, &n1, &n2);
		judge = compare(cardnum[n1], cardnum[n2], index, index_res);
		if (judge == true)
		{

			_sleep(500);
			erasecard(n1, n2);
			count++;
		}
		else
		{
			_sleep(500);
			backcard(n1, n2);
		}
		if (count >= num * 4)
			break;
	}
	print_End();

	if (MENU4() == 1)
	{
		write_info();
		if (MENU5() == 1)
		{
			print_info();
			Sleep(1000);
			MENU_END(); 
		}
		else
		
			MENU_END();
	}
	else
		MENU_END();

	return 0;
}
