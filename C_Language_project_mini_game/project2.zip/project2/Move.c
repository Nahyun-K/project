#include<stdio.h>
#include<string.h>
#include "puzzle.h"

void moving(char(*cardnum)[10], int *n1, int *n2)
{
	int x = 0, y = 0;
	int p = 0;
	int m = 0, n, l;
	if (num == 2)
	{
		p = 12;
	}
	int a = 0;
	while (1)
	{
		if (strcmp(cardnum[a], " ") != 0)
		{
			x = a % 4 * 6;
			y = a / 4 * 6;
			readycard(x, y);
			break;
		}
		else
		{
			if (a > num * 8)   break;
			a++;
		}
	}


	while (1)
	{
		switch (_getch())
		{
		case UP:
			m = 0; n = x;   l = y;
			if (y > 0)
			{
				while (x >= 0)
				{
					y = l;
					while (y > 0)
					{
						y -= 6;
						int a = x / 6;
						a += y / 6 * 4;
						if (strcmp(cardnum[a], " ") == 0);
						else
						{
							closecard(n, l);
							readycard(x, y);
							m = 1;
							break;
						}
					}
					if (m == 1)   break;
					else x -= 6;
				}
			}

			if (m == 0)
			{
				x = n;   y = l;
			}
			break;
		case DOWN:
			m = 0;  n = x;   l = y;
			if (y < 6 + p)
			{
				while (x >= 0)
				{
					y = l;
					while (y < 6 + p)
					{
						y += 6;
						int a = x / 6;
						a += y / 6 * 4;
						if (strcmp(cardnum[a], " ") == 0);
						else
						{
							closecard(n, l);
							readycard(x, y);
							m = 1;
							break;
						}
					}
					if (m == 1)      break;
					else x -= 6;
				}
			}
			if (m == 0)
			{
				x = n;   y = l;
			}
			break;
		case LEFT:
			m = 0; n = x;   l = y;
			if (x > 0)
			{
				while (y >= 0)
				{
					x = n;
					while (x > 0)
					{
						x -= 6;
						int a = x / 6;
						a += y / 6 * 4;
						if (strcmp(cardnum[a], " ") == 0);
						else
						{
							closecard(n, l);
							readycard(x, y);
							m = 1;
							break;
						}
					}
					if (m == 1)   break;
					else y -= 6;
				}
			}
			if (m == 0)
			{
				x = n;   y = l;
			}
			break;
		case RIGHT:
			m = 0; n = x;   l = y;
			if (x < 18)
			{
				while (y <= 6 + p)
				{
					x = n;
					while (x < 18)
					{
						x += 6;
						int a = x / 6;
						a += y / 6 * 4;
						if (strcmp(cardnum[a], " ") == 0);
						else
						{
							closecard(n, l);
							readycard(x, y);
							m = 1;
							break;
						}
					}
					if (m == 1)   break;
					else y += 6;
				}
			}
			if (m == 0)
			{
				x = n;   y = l;
			}
			break;
		case ENTER:
			open(x, y);
			printcard(x, y, cardnum);
			int a = x, b = y;
			while (1)
			{
				switch (_getch())
				{

				case UP:
					m = 0; n = a;   l = b;
					if (b > 0)
					{
						while (a >= 0)
						{
							b = l;
							while (b > 0)
							{
								b -= 6;
								int k = a / 6;
								k += b / 6 * 4;
								if (strcmp(cardnum[k], " ") == 0);
								else if (b == y && a == x);
								else
								{
									closecard(n, l);
									open(x, y);
									printcard(x, y, cardnum);
									readycard(a, b);
									m = 1;
									break;
								}
							}
							if (m == 1)   break;
							else a -= 6;
						}
					}
					if (m == 0)
					{
						a = n;   b = l;
					}
					break;
				case DOWN:
					m = 0;  n = a;   l = b;
					if (b < 6 + p)
					{
						while (a >= 0)
						{
							b = l;
							while (b < 6 + p)
							{
								b += 6;
								int k = a / 6;
								k += b / 6 * 4;
								if (strcmp(cardnum[k], " ") == 0);
								else if (b == y && a == x);
								else
								{
									closecard(n, l);
									open(x, y);
									printcard(x, y, cardnum);
									readycard(a, b);
									m = 1;
									break;
								}
							}
							if (m == 1)      break;
							else a -= 6;
						}
					}
					if (m == 0)
					{
						a = n;   b = l;
					}
					break;
				case LEFT:
					m = 0; n = a;   l = b;
					if (a > 0)
					{
						while (b >= 0)
						{
							a = n;
							while (a > 0)
							{
								a -= 6;
								int k = a / 6;
								k += b / 6 * 4;
								if (strcmp(cardnum[k], " ") == 0);
								else if (b == y && a == x);
								else
								{
									closecard(n, l);
									open(x, y);
									printcard(x, y, cardnum);
									readycard(a, b);
									m = 1;
									break;
								}
							}
							if (m == 1)   break;
							else b -= 6;
						}
					}
					if (m == 0)
					{
						a = n;   b = l;
					}
					break;
				case RIGHT:
					m = 0; n = a;   l = b;
					if (a < 18)
					{
						while (b <= 6 + p)
						{
							a = n;
							while (a < 18)
							{
								a += 6;
								int k = a / 6;
								k += b / 6 * 4;
								if (strcmp(cardnum[k], " ") == 0);
								else if (b == y && a == x);
								else
								{
									closecard(n, l);
									open(x, y);
									printcard(x, y, cardnum);
									readycard(a, b);
									m = 1;
									break;
								}
							}
							if (m == 1)   break;
							else b += 6;
						}
					}
					if (m == 0)
					{
						a = n;   b = l;
					}
					break;
				case ENTER:
					if (a != x || b != y)
					{
						open(a, b);
						*n1 = printcard(x, y, cardnum);
						*n2 = printcard(a, b, cardnum);
						return;
					}
				}
			}
			break;
		}
	}
}


