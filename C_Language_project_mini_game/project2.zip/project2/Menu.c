#include<stdio.h>
#include "puzzle.h"


int MENU2()
{
	int updown = 1;

	gotoxy(12, 6);
	printf("[ ���� ���� ]");
	gotoxy(13, 8);
	printf(" ������");
	gotoxy(13, 9);
	printf(" ���ĺ� ��ҹ���");
	gotoxy(11, 8);
	printf("��");

	while (1)
	{
		switch (_getch())
		{
		case UP:
			updown = 1;
			gotoxy(11, 8);
			printf("��");
			gotoxy(11, 9);
			printf(" ");
			break;
		case DOWN:
			updown = 2;
			gotoxy(11, 8);
			printf(" ");
			gotoxy(11, 9);
			printf("��");
			break;
		case ENTER:
			if (updown == 1)
			{
				system("cls");
				return sub = 1;
			}
			else if (updown == 2)
			{
				system("cls");
				return sub = 2;
			}
		}
	}
}

int MENU3()
{
	int updown = 1;

	gotoxy(11, 6);
	printf("[ ���̵� ���� ]");
	gotoxy(13, 8);
	printf(" 4 x 2");
	gotoxy(13, 9);
	printf(" 4 x 4");
	gotoxy(11, 8);
	printf("��");

	while (1)
	{
		switch (_getch())
		{
		case UP:
			updown = 1;
			gotoxy(11, 8);
			printf("��");
			gotoxy(11, 9);
			printf(" ");
			break;
		case DOWN:
			updown = 2;
			gotoxy(11, 8);
			printf(" ");
			gotoxy(11, 9);
			printf("��");
			break;
		case ENTER:
			if (updown == 1)
			{
				system("cls");
				return num = 1;
			}
			else if (updown == 2)
			{
				system("cls");
				return num = 2;
			}
		}
	}
}

void dan()
{
	int updown = 0;

	gotoxy(12, 6);
	printf("[ �� ���� ]");
	gotoxy(13, 8);
	printf(" 2 ��");
	gotoxy(13, 9);
	printf(" 3 ��");
	gotoxy(13, 10);
	printf(" 4 ��");
	gotoxy(13, 11);
	printf(" 5 ��");
	gotoxy(13, 12);
	printf(" 6 ��");
	gotoxy(13, 13);
	printf(" 7 ��");
	gotoxy(13, 14);
	printf(" 8 ��");
	gotoxy(13, 15);
	printf(" 9 ��");

	gotoxy(11, 8);
	printf("��");

	while (1)
	{
		switch (_getch())
		{
		case UP:
			updown--;
			if (updown < 0)
			{
				updown++;
			}
			gotoxy(11, 8 + updown);
			printf("��");
			gotoxy(11, 9 + updown);
			printf(" ");
			break;
		case DOWN:
			updown++;
			if (updown > 7)
			{
				updown--;
			}
			gotoxy(11, 7 + updown);
			printf(" ");
			gotoxy(11, 8 + updown);
			printf("��");
			break;
		case ENTER:
			system("cls");
			return ggdan = updown + 2;
		}
	}
}
