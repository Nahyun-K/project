class TV {
	private int size;
	public TV(int size) { this.size= size; }
	protected int getSize() { return size; }
}


public class Midterm01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] num = {3, 7, 2, 9, 1};
		
		printStar();
		System.out.println("�ִ밪: "+returnMaxVal(num));
		//3�� ���� �ڵ�
		Complex c1 = new Comlex(2.0);
		c1.print();
		Complex c2 = new Comlex(1.5, 2.5);
		c2.print();
		
		//4.(1)�� ���� �ڵ�
		ColorTV myTV = new ColorTV(32, 1024);
		myTV.printProperty();
		
		//4.(2)�� ���� �ڵ�
		IPTV ipTV = new IPTV("127.0.0.1", 32, 2048);
		ipTV.printProperty();
		
	}
	public static void printStar() {
		
	}
	public static int returnMaxVal(int [] n) {
		
		return 0;
	}
}
