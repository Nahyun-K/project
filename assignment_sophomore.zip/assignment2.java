package new_project;


public class assignment2 {

	public static void main(String[] args) {
		DoublyLinkedList<GameEntry> doublyLinkedList = new DoublyLinkedList<GameEntry>();

		String[] names = {"Rob", "Mike", "Rose", "Jill", "Jack", "Paul", "Bob"};
		String[] removes = {"Mike", "Paul", "Bob"};
		int[] scores = { 750, 1105, 590, 740, 610, 410, 840 };

		for (int s = 0; s < names.length; s++) {

			GameEntry x =new GameEntry(names[s], scores[s]);

			doublyLinkedList.add(x);

			System.out.println(doublyLinkedList.toString("Added"));

		}
		for(int k=0;k <removes.length;k++) {

			doublyLinkedList.remove(removes[k]);
			System.out.println(doublyLinkedList.toString("removed"));

		}

	}



}