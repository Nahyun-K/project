package new_project;

import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public class assignment3 {
	public static void main(String[] args) {
		PuzzleSolve(3, "", "abcd");
	}
static void PuzzleSolve(int j, String A, String B) {

	for(int i = 0;i < j;i++) {
		String change = " "+A.charAt(i);
		A = A.replace(change, "");
		B = B.concat(change);
		if(j == 1)		System.out.println(A);
		else			PuzzleSolve(j - 1,A,B);
		B=change.concat(B);
		A=A.replace(change, "");
	}
}
}
